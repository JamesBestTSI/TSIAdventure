#include "CharacterFaces.h"

CharacterFaces::CharacterFaces(){};
CharacterFaces::~CharacterFaces(){};
