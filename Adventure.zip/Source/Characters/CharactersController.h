#ifndef CHARACTERSCONTROLLER_H
#define CHARACTERSCONTROLLER_H
#include "Character.h"

class CharactersController{
    
    public:
    CharactersController();
    ~CharactersController();
    Character gameCharacters[6];


};
#endif