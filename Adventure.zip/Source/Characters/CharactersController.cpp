#include "CharactersController.h"

    CharactersController::CharactersController(){};
    CharactersController::~CharactersController(){};